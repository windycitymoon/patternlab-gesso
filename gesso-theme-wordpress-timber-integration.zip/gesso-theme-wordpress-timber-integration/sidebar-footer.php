<aside class="footer-sidebar" role="complementary">
	<div class="footer-sidebar__widgets">
		<?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-widgets')) ?>
	</div>
</aside>
