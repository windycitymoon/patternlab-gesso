module.exports = function (grunt) {
  grunt.registerTask('gessoBuildImages', [
    'svg2png'
  ]);
};
